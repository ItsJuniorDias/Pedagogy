/**
 * nicknames.ts — Gerador de apelido fofo no cliente (fallback offline).
 *
 * Normalmente quem dá o apelido é o servidor (autoritativo). Este gerador é
 * usado só quando o jogo roda sem servidor ou enquanto a conexão não chegou,
 * pra que a UI nunca fique sem um `{ nick, emoji }` fofinho para mostrar.
 */

import type { Identity } from "./protocol";

const EMOJIS = [
  "🦊", "🐼", "🐱", "🐶", "🦄", "🐧", "🐸", "🐢", "🦉", "🐙",
  "🦖", "🐝", "🦋", "🐞", "🐬", "🦔", "🐨", "🐯", "🦁", "🐰",
  "🌟", "🍕", "🍓", "🌈", "👾", "🚀", "🔥", "⚡", "🎈", "🍩",
];

const ADJ = [
  "Fofo", "Veloz", "Doido", "Saltitante", "Brilhante", "Travesso",
  "Turbo", "Mágico", "Faminto", "Sonolento", "Ninja", "Espacial",
  "Geleia", "Pixelado", "Estelar", "Fominha", "Risonho", "Atrevido",
  "Foguete", "Marshmallow", "Caramelo", "Trovão", "Confete", "Picante",
];

const NOUN = [
  "Raposa", "Panda", "Gatinho", "Pinguim", "Sapo", "Tartaruga",
  "Unicórnio", "Polvo", "Coruja", "Abelha", "Borboleta", "Capivara",
  "Coelho", "Dino", "Lhama", "Foca", "Tigre", "Lontra",
  "Esquilo", "Ouriço", "Golfinho", "Joaninha", "Morcego", "Filhote",
];

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

/** Apelido fofo local (sem id de servidor). */
export function makeLocalNickname(): Identity {
  return {
    id: `local_${Math.random().toString(36).slice(2, 9)}`,
    nick: `${pick(ADJ)}${pick(NOUN)}`,
    emoji: pick(EMOJIS),
  };
}

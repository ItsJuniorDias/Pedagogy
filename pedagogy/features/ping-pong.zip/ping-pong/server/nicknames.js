/**
 * nicknames.js — Gerador de apelidos fofinhos (emoji + nick) no servidor.
 *
 * O servidor é a AUTORIDADE do apelido: cada jogador que conecta ganha um
 * `{ nick, emoji }` aleatório e fofo, garantidamente único entre quem está
 * online no momento. O cliente apenas exibe o que recebe.
 */

const EMOJIS = [
  "🦊", "🐼", "🐱", "🐶", "🦄", "🐧", "🐸", "🐢", "🦉", "🐙",
  "🦖", "🐝", "🦋", "🐞", "🐬", "🦔", "🐨", "🐯", "🦁", "🐰",
  "🌟", "🍕", "🍓", "🌈", "👾", "🚀", "🔥", "⚡", "🎈", "🍩",
];

const ADJ = [
  "Fofo", "Veloz", "Doido", "Saltitante", "Brilhante", "Travesso",
  "Turbo", "Mágico", "Faminto", "Sonolento", "Ninja", "Espacial",
  "Geleia", "Pixelado", "Estelar", "Fominha", "Risonho", "Atrevido",
  "Foguete", "Marshmallow", "Caramelo", "Trovão", "Confete", "Picante",
];

const NOUN = [
  "Raposa", "Panda", "Gatinho", "Pinguim", "Sapo", "Tartaruga",
  "Unicórnio", "Polvo", "Coruja", "Abelha", "Borboleta", "Capivara",
  "Coelho", "Dino", "Lhama", "Foca", "Tigre", "Lontra",
  "Esquilo", "Ouriço", "Golfinho", "Joaninha", "Morcego", "Filhote",
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

/**
 * Gera um apelido fofo único.
 * @param {Set<string>} taken nicks já em uso (para evitar repetição)
 */
export function makeNickname(taken = new Set()) {
  for (let i = 0; i < 40; i++) {
    const emoji = pick(EMOJIS);
    const nick = `${pick(ADJ)}${pick(NOUN)}`;
    if (!taken.has(nick)) return { nick, emoji };
  }
  // fallback com sufixo numérico se (improvável) tudo colidir
  const emoji = pick(EMOJIS);
  const nick = `${pick(ADJ)}${pick(NOUN)}${Math.floor(Math.random() * 999)}`;
  return { nick, emoji };
}
